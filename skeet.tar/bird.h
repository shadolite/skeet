/*************************************************************
 * File: bird.h
 * Author: Amy Chambers
 *
 * Description: Defines Bird
 *************************************************************/

#ifndef BIRD_H
#define BIRD_H

#include "flyingObject.h"

class Bird : public FlyingObject
{
private:
   int hp;
   int points;
   
public:
   Bird(Point);
   int hit();
      
   
};

#endif
