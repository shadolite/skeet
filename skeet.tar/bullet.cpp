/*************************************************************
 * File: bullet.cpp
 * Author: Amy Chambers
 *
 * Description: Contains the function bodies for Bullet
 *************************************************************/

#include "bullet.h"
#include "uiDraw.h"
#include ""

#include <cassert>

Bullet :: Bullet()
{
   setVelocity();
   setPoint();
};

void Bullet :: fire(const Point point, const float angle) 
{

}

void Bullet :: draw()
{
   drawDot(point);
}
