/*************************************************************
 * File: bullet.h
 * Author: Amy Chambers
 *
 * Description: Defines Bullet
 *************************************************************/

#ifndef BULLET_H
#define BULLET_H

#include "flyingObject.h"

class Bullet : public FlyingObject
{
private:

   
public:
   Bullet();
   void fire(Point point, float angle);
   void draw();
   
};

#endif
