/*************************************************************
 * File: sBird.h
 * Author: Amy Chambers
 *
 * Description: Defines sBird
 *************************************************************/

#ifndef SBIRD_H
#define SBIRD__H

#include "bird.h"


class sBird : public Bird
{
private:

   
public:
   sBird();
   void draw();
};

#endif
